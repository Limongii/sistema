<?php

include 'config.php';

// Processa o formulário quando é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $placa = $_POST['placa'];$hodometro = $_POST['hodometro'];
    $posto_id = $_POST['posto'];


    // Prepara e executa a inserção
    $sql = "INSERT INTO motorista (nome, placa, hodometro, posto_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $nome, $placa, $hodometro, $posto_id);


if ($stmt->execute()) {
    // Exibe a mensagem e redireciona após 1 segundo
    echo "<script>
            alert('Dados enviados com sucesso!');
            setTimeout(function(){
                window.location.href = 'bem-vindo.php';
            }, 1000); // 1000 milissegundos = 1 segundo
          </script>";
} else {
    echo "Erro: " . $stmt->error;
}




    $stmt->close();
}