<?php
include 'config.php';

// Processa o formulário quando é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $placa = $_POST['placa'];
    $hodometro = $_POST['hodometro'];
    $posto_id = $_POST['posto'];

    // Inicializa a variável de imagem
    $imagem = "";

    // Verifica se o campo de imagem foi enviado e processa o upload da imagem
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagem = $_FILES['imagem']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($imagem);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verifica se o arquivo é uma imagem real
        $check = getimagesize($_FILES['imagem']['tmp_name']);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "O arquivo não é uma imagem.";
            $uploadOk = 0;
        }

        // Verifica se o arquivo já existe
        if (file_exists($target_file)) {
            echo "Desculpe, o arquivo já existe.";
            $uploadOk = 0;
        }

        // Verifica o tamanho do arquivo
        if ($_FILES['imagem']['size'] > 500000) {
            echo "Desculpe, o seu arquivo é muito grande.";
            $uploadOk = 0;
        }

        // Permite apenas certos formatos de arquivo
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            echo "Desculpe, apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
            $uploadOk = 0;
        }

        // Verifica se $uploadOk está definido como 0 por um erro
        if ($uploadOk == 0) {
            echo "Desculpe, o seu arquivo não foi enviado.";
        // Se tudo estiver ok, tenta fazer o upload do arquivo
        } else {
            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target_file)) {
                echo "O arquivo ". htmlspecialchars(basename($imagem)). " foi enviado com sucesso.";
            } else {
                echo "Desculpe, houve um erro ao enviar o seu arquivo.";
            }
        }
    }

    // Prepara e executa a inserção
    $sql = "INSERT INTO motorista (nome, placa, hodometro, posto_id, imagem) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiss", $nome, $placa, $hodometro, $posto_id, $imagem);

    if ($stmt->execute()) {
        echo "<script>
                alert('Dados enviados com sucesso!');
                
              </script>";
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
	
	
	
	
	
	
	
}
?>
